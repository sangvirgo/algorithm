/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bai1NangCao;

/**
 *
 * @author soang
 */
public class Main {
    public static void main(String[] args) {
        SinhVien sv1 = new SinhVien();
        sv1.init();
        sv1.display();
    }
}
